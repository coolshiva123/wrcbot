BACKEND='SlackV3'
BOT_DATA_DIR = '/errbot/data'
BOT_EXTRA_PLUGIN_DIR = '/errbot/src/plugins'
BOT_LOG_FILE = '/errbot/errbot.log'
BOT_EXTRA_BACKEND_DIR = '/opt/errbot/backend'
BOT_LOG_LEVEL = 'DEBUG'
BOT_ADMINS = ('@awsterraform30',)  # Replace with your username if needed
BOT_IDENTITY = {
    'token': '',
    'signing_secret': '',
    'app_token': ''
}
BOT_PREFIX = '<>'  # Replace with your bot's user ID


