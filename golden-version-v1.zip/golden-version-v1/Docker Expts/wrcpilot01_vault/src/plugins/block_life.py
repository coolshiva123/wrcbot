BLOCKS_PRIORLIFE = [
    {
        "type": "section",
        "text": {"type": "mrkdwn", "text": "Click the button to provide your input:"}
    },
    {
        "type": "actions",
        "elements": [
            {
                "type": "button",
                "text": {"type": "plain_text", "text": "Provide Input"},
                "action_id": "provide_input"
            }
        ]
    }
]