BACKEND = 'Text'  # Use the Text backend for local testing

BOT_DATA_DIR = '/errbot/data'
BOT_EXTRA_PLUGIN_DIR = '/errbot/src/plugins'
BOT_LOG_FILE = '/errbot/errbot.log'
BOT_LOG_LEVEL = 'DEBUG'
BOT_ADMINS = ('@admin',)  # Replace with your username if needed