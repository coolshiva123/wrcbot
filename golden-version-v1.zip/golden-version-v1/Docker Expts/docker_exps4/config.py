BACKEND = 'SlackV3'
BOT_DATA_DIR = './data'
BOT_EXTRA_PLUGIN_DIR = './plugins'
BOT_LOG_FILE = './errbot.log'
BOT_LOG_LEVEL = 'INFO'
BOT_ADMINS = ('@awsterraform30',)
BOT_IDENTITY = {
    'token': '',   # Replace with your bot's token
    'signing_secret': '',  # Replace with your bot's signing secret
    'app_token': ''
     }
BOT_PREFIX = '<>'  # Replace with your bot's user ID
BOT_EXTRA_BACKEND_DIR = './backends'